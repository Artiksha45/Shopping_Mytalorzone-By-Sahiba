body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #333;
    color: white;
    padding: 10px 20px;
}

.logo a {
    color: white;
    text-decoration: none;
    font-size: 24px;
}

.menu {
    display: none; /* Initially hidden */
}

.menu ul {
    list-style: none;
    padding: 0;
}

.menu ul li {
    display: inline;
    margin: 0 10px;
}

.menu ul li a {
    color: white;
    text-decoration: none;
}

.contact-section {
    padding: 20px;
}

.contact-form {
    display: flex;
    flex-direction: column;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    margin-bottom: 5px;
}

.form-group input,
.form-group textarea {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    padding: 10px;
    background-color: #28a745;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #218838;
}

footer {
    background-color: #333;
    color: white;
    padding: 20px;
    text-align: center;
}

.social-media a {
    margin: 0 10px;
    color: white;
}